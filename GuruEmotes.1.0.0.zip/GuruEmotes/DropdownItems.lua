-- 45 per menu max
GuruEmotes_dropdown_options = {
    [01] = { -- 45
        "Guru"
    }
};