local GuruEmotes_TimeSinceLastUpdate = 0
local GuruEmotes_T = 0;

function GuruEmotesAnimator_OnUpdate(self, elapsed)

    if (GuruEmotes_TimeSinceLastUpdate >= 0.033) then
        -- Update animated emotes in chat windows
        for i = 1, NUM_CHAT_WINDOWS do
            for _, visibleLine in ipairs(_G["ChatFrame" .. i].visibleLines) do
                if(_G["ChatFrame" .. i]:IsShown() and visibleLine.messageInfo ~= GuruEmotes_HoverMessageInfo) then 
                    GuruEmotesAnimator_UpdateEmoteInFontString(visibleLine, 28, 28);
                end
            end
        end

        -- Update animated emotes in suggestion list
        if (EditBoxAutoCompleteBox and EditBoxAutoCompleteBox:IsShown() and
            EditBoxAutoCompleteBox.existingButtonCount ~= nil) then
            for i = 1, EditBoxAutoCompleteBox.existingButtonCount do
                local cBtn = EditBoxAutoComplete_GetAutoCompleteButton(i);
                if (cBtn:IsVisible()) then
                    GuruEmotesAnimator_UpdateEmoteInFontString(cBtn, 16, 16);
                else
                    break
                end
            end
        end

        -- Update animated emotes in statistics screen
        if(TwitchStatsScreen:IsVisible()) then
           
            local topSentImagePath = GuruEmotes_defaultpack[GuruEmotesentStatKeys[1]] or "Interface\\AddOns\\GuruEmotes\\Emotes\\1337.tga";
            local animdata = GuruEmotes_animation_metadata[topSentImagePath:match("(Interface\\AddOns\\GuruEmotes\\Emotes.-.tga)")]
            
            if(animdata ~= nil) then
                local cFrame = GuruEmotes_GetCurrentFrameNum(animdata)
                TwitchStatsScreen.topSentEmoteTexture:SetTexCoord(GuruEmotes_GetTexCoordsForFrame(animdata, cFrame)) 
            end
                

            local topSeenImagePath = GuruEmotes_defaultpack[TwitchEmoteRecievedStatKeys[1]] or "Interface\\AddOns\\GuruEmotes\\Emotes\\1337.tga";
            local animdata = GuruEmotes_animation_metadata[topSeenImagePath:match("(Interface\\AddOns\\GuruEmotes\\Emotes.-.tga)")]
            if(animdata ~= nil) then
                local cFrame = GuruEmotes_GetCurrentFrameNum(animdata)
                TwitchStatsScreen.topSeenEmoteTexture:SetTexCoord(GuruEmotes_GetTexCoordsForFrame(animdata, cFrame)) 
            end
            

            for line=1, 17 do
                local sentEntry = getglobal("TwitchStatsSentEntry"..line)
                local recievedEntry = getglobal("TwitchStatsRecievedEntry"..line)

                if(sentEntry:IsVisible()) then
                    GuruEmotesAnimator_UpdateEmoteInFontString(sentEntry, 16, 16);
                end

                if(recievedEntry:IsVisible()) then
                    GuruEmotesAnimator_UpdateEmoteInFontString(recievedEntry, 16, 16);
                end
            end
        end
        

        GuruEmotes_TimeSinceLastUpdate = 0;
    end

    GuruEmotes_T = GuruEmotes_T + elapsed
    GuruEmotes_TimeSinceLastUpdate = GuruEmotes_TimeSinceLastUpdate +
                                        elapsed;
end

local function escpattern(x)
    return (
            --x:gsub('%%', '%%%%')
             --:gsub('^%^', '%%^')
             --:gsub('%$$', '%%$')
             --:gsub('%(', '%%(')
             --:gsub('%)', '%%)')
             --:gsub('%.', '%%.')
             --:gsub('%[', '%%[')
             --:gsub('%]', '%%]')
             --:gsub('%*', '%%*')
             x:gsub('%+', '%%+')
             :gsub('%-', '%%-')
             --:gsub('%?', '%%?'))
            )
end

-- This will update the texture escapesequence of an animated emote
-- if it exsists in the contents of the fontstring
function GuruEmotesAnimator_UpdateEmoteInFontString(fontstring, widthOverride, heightOverride)
    local txt = fontstring:GetText();
    if (txt ~= nil) then
        for emoteTextureString in txt:gmatch("(|TInterface\\AddOns\\GuruEmotes\\Emotes.-|t)") do
            local imagepath = emoteTextureString:match("|T(Interface\\AddOns\\GuruEmotes\\Emotes.-.tga).-|t")

            local animdata = GuruEmotes_animation_metadata[imagepath];
            if (animdata ~= nil) then
                local framenum = GuruEmotes_GetCurrentFrameNum(animdata);
                local nTxt;
                if(widthOverride ~= nil or heightOverride ~= nil) then
                    nTxt = txt:gsub(escpattern(emoteTextureString),
                                        GuruEmotes_BuildEmoteFrameStringWithDimensions(
                                        imagepath, animdata, framenum, widthOverride, heightOverride))
                else
                    nTxt = txt:gsub(escpattern(emoteTextureString),
                                      GuruEmotes_BuildEmoteFrameString(
                                        imagepath, animdata, framenum))
                end

                -- If we're updating a chat message we need to alter the messageInfo as wel
                if (fontstring.messageInfo ~= nil) then
                    fontstring.messageInfo.message = nTxt
                end
                fontstring:SetText(nTxt);
                txt = nTxt;
            end
        end
    end
end



function GuruEmotes_GetAnimData(imagepath)
    return GuruEmotes_animation_metadata[imagepath]
end

function GuruEmotes_GetCurrentFrameNum(animdata)
    return math.floor((GuruEmotes_T * animdata.framerate) % animdata.nFrames);
end

function GuruEmotes_GetTexCoordsForFrame(animdata, framenum)
    local fHeight = 1/animdata.nFrames
    return 0, 1 ,framenum * fHeight, (framenum * fHeight) + fHeight
end

function GuruEmotes_BuildEmoteFrameString(imagepath, animdata, framenum)
    local top = framenum * animdata.frameHeight;
    local bottom = top + animdata.frameHeight;

    local emoteStr = "|T" .. imagepath .. ":" .. animdata.frameWidth .. ":" ..
                        animdata.frameHeight .. ":0:0:" .. animdata.imageWidth ..
                        ":" .. animdata.imageHeight .. ":0:" ..
                        animdata.frameWidth .. ":" .. top .. ":" .. bottom ..
                        "|t";
    return emoteStr
end

function GuruEmotes_BuildEmoteFrameStringWithDimensions(imagepath, animdata,
                                                        framenum, framewidth,
                                                        frameheight)
    local top = framenum * animdata.frameHeight;
    local bottom = top + animdata.frameHeight;

    local emoteStr = "|T" .. imagepath .. ":" .. framewidth .. ":" ..
                        frameheight .. ":0:0:" .. animdata.imageWidth .. ":" ..
                        animdata.imageHeight .. ":0:" .. animdata.frameWidth ..
                        ":" .. top .. ":" .. bottom .. "|t";
    return emoteStr
end